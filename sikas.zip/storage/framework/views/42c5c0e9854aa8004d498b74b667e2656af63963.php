<?php $__env->startSection('title', 'Login - Sikas'); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/page-auth.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl">
  <div class="authentication-wrapper authentication-basic container-p-y">
    <div class="authentication-inner">
      <!-- Register -->
      <div class="card">
        <div class="card-body">
          <!-- Logo -->
          <div class="app-brand justify-content-center">
            <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
              <img src="<?php echo e(asset('assets/img/sikas/logo.png')); ?>" class="app-brand-logo"></img>
            </a>
          </div>
          <!-- /Logo -->
          <h5 class="auth-subtitle text-center">Sistem Pembayaran dan Kas Sekolah</h5>

          <?php if(Session::has('error')): ?>
          <div class="alert alert-danger alert-dismissible" role="alert">
            <?php echo e(Session::get('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            </button>
          </div>
          <?php endif; ?>

          <form id="formAuthentication" class="mb-3" action="<?php echo e(url('/authenticate')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="mb-3">
              <label for="email" class="form-label">Email atau Username</label>
              <input type="text" class="form-control" id="email" name="username" placeholder="Masukkan email atau username anda" autofocus>
            </div>
            <div class="mb-3 form-password-toggle">
              <div class="d-flex justify-content-between">
                <label class="form-label" for="password">Password</label>
                <!-- <a href="<?php echo e(url('auth/forgot-password-basic')); ?>">
                  <small>Forgot Password?</small>
                </a> -->
              </div>
              <div class="input-group input-group-merge">
                <input type="password" id="password" class="form-control" name="password" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" aria-describedby="password" />
                <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
              </div>
            </div>
            <div class="">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="remember-me">
                <label class="form-check-label" for="remember-me">
                  Remember Me
                </label>
              </div>
            </div>
            <div class="mt-5">
              <button class="btn btn-primary d-grid w-100" type="submit">Sign in</button>
            </div>
          </form>

          <!-- <p class="text-center">
            <span>Belum punya akun?</span>
            <a href="<?php echo e(url('/')); ?>">
              <span>buat disini</span>
            </a>
          </p> -->
        </div>
      </div>
    </div>
    <!-- /Register -->
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sikas/layout/blankLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/faisal/Documents/IlliyinStudio/Web/sikas/resources/views/sikas/login.blade.php ENDPATH**/ ?>