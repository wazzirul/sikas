<?php $__env->startSection('title', 'Laporan - Sikas'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/printjs/print.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/daterangepicker/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/printjs/print.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/datatable-tables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/laporan.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/sikas-laporan.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('current-pages-title'); ?>
Laporan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="jenis-laporan mb-5">
  <div class="card">
    <div class="card-body">
      <input type="hidden" id="ctoken" value="<?php echo e(csrf_token()); ?>">
      <a href="<?php echo e(route('sikas-laporan--penggunaan-dana')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-laporan__link">
        <div class="jenis-laporan__icon-wrap">
          <i class="fa-solid fa-school jenis-laporan__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-laporan__icon jenis-laporan__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5 jenis-laporan__name">Laporan Penggunaan Dana</h5>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <a href="<?php echo e(route('sikas-laporan--pemasukan-dari-sumber-lain')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-laporan__link">
        <div class="jenis-laporan__icon-wrap">
          <i class="fa-regular fa-building jenis-laporan__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-laporan__icon jenis-laporan__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5 jenis-laporan__name">Laporan Pemasukan dari Sumber Lain</h5>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <a href="<?php echo e(route('sikas-laporan--pengajuan-keringanan')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-laporan__link">
        <div class="jenis-laporan__icon-wrap">
          <i class="fa-solid fa-money-bill-wave jenis-laporan__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-laporan__icon jenis-laporan__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5 jenis-laporan__name">Laporan Pengajuan Keringanan</h5>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <a href="<?php echo e(route('sikas-laporan--pembayaran-spp')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-laporan__link">
        <div class="jenis-laporan__icon-wrap">
          <i class="fa-solid fa-graduation-cap jenis-laporan__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-laporan__icon jenis-laporan__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5 jenis-laporan__name">Laporan Pembayaran SPP</h5>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <a href="<?php echo e(route('sikas-laporan--pembayaran-tabungan')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-laporan__link">
        <div class="jenis-laporan__icon-wrap">
          <i class="fa-solid fa-credit-card jenis-laporan__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-laporan__icon jenis-laporan__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5 jenis-laporan__name">Laporan Pembayaran Tabungan</h5>
    </div>
  </div>
</div>
<div class="card card--laporan">
  <div class="laporan-wrapper">
    <h4 class="text-bold color-black mb-4">Data Laporan</h4>
    <div class="d-flex align-items-center justify-content-end gap-4 mb-5">
      <div class="date-range">
        <div id="date-range-span" class="form-control">
          <span></span>
        </div>
        <i class="fa-regular fa-calendar-days date-range-icon text-primary"></i>
        <input type="hidden" name="date-range-input" value="" class="" id="date-range-input" />
      </div>
      <button class="d-flex btn btn-primary gap-2 align-items-center" id="button-cetak-laporan">
        Cetak Laporan
        <i class="fa-solid fa-plus"></i>
      </button>
    </div>
    <div class="table-responsive text-nowrap">
      <table class="table table-striped" id="data-laporan">
        <thead>
          <tr>
            <th rowspan="2" align="center">
              <h6 class="text-bold color-black">Tanggal</h6>
            </th>
            <th rowspan="2" align="center" class="data-laporan__keterangan">
              <h6 class="text-bold color-black">Keterangan</h6>
            </th>
            <th colspan="2">
              <h6 class="text-bold color-black">Dana Penunjang Kegiatan Sekolah (BPP)</h6>
            </th>
            <th colspan="2">
              <h6 class="text-bold color-black">Tabungan UMUM</h6>
            </th>
          </tr>
          <tr>
            <th>
              <p class="text-bold color-black">Debet</p>
            </th>
            <th>
              <p class="text-bold color-black">Kredit</p>
            </th>
            <th>
              <p class="text-bold color-black">Debet</p>
            </th>
            <th>
              <p class="text-bold color-black">Kredit</p>
            </th>
          </tr>
        </thead>
        <tbody id="tbody-laporan">
          <!-- Saldo -->
          <tr>
            <td>
              <p class="text-bold text-primary"><?php echo e(\Carbon\Carbon::now()->format('d F Y')); ?></p>
            </td>
            <td class="data-laporan__keterangan">
              <p class="text-bold text-primary">Saldo <?php echo e(\Carbon\Carbon::now()->format('F Y')); ?></p>
            </td>
            <td>
              <p class="text-bold text-primary nominal-transaksi"><?php echo e($bpp_sekolah); ?></p>
            </td>
            <td>
              <p class="text-bold text-primary nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-bold text-primary nominal-transaksi"><?php echo e($tabungan_sekolah); ?></p>
            </td>
            <td>
              <p class="text-bold text-primary nominal-transaksi">-</p>
            </td>
          </tr>

          <!-- Penerimaan BPP -->
          <tr>
            <td>
              <?php if($data_spp_bulan_ini != null): ?>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::parse($data_spp_bulan_ini->tanggal)->format('d F Y')); ?></p>
              <?php else: ?>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::now()->format('d F Y')); ?></p>
              <?php endif; ?>
            </td>
            <td class="data-laporan__keterangan">
              <p class="text-medium color-neutral-100">Penerimaan BPP</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi"><?php echo e($spp_bulan_ini); ?></p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
          </tr>

          <!-- Penerimaan Tabungan -->
          <tr>
            <td>
              <?php if($data_tabungan_bulan_ini != null): ?>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::parse($data_tabungan_bulan_ini->tanggal)->format('d F Y')); ?></p>
              <?php else: ?>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::now()->format('d F Y')); ?></p>
              <?php endif; ?>
            </td>
            <td class="data-laporan__keterangan">
              <p class="text-medium color-neutral-100">Penerimaan Tabungan</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi"><?php echo e($tabungan_bulan_ini); ?></p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
          </tr>

          <!-- Penarikan Tabungan -->
          <tr>
            <td>
              <?php if($data_tarik_tabungan_bulan_ini != null): ?>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::parse($data_tarik_tabungan_bulan_ini->tanggal)->format('d F Y')); ?></p>
              <?php else: ?>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::now()->format('d F Y')); ?></p>
              <?php endif; ?>
            </td>
            <td class="data-laporan__keterangan">
              <p class="text-medium color-neutral-100">Penarikan Tabungan</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi"><?php echo e($tarik_tabungan_bulan_ini); ?></p>
            </td>
          </tr>

          <?php $__currentLoopData = $transaksi_lain_bulan_ini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tlbi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::parse($tlbi->tanggal)->format('d F Y')); ?></p>
            </td>
            <td class="data-laporan__keterangan">
              <p class="text-medium color-neutral-100"><?php echo e($tlbi->nama_transaksi); ?></p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi"><?php echo e($tlbi->tipe_transaksi == 5 ? $tlbi->jumlah : '-'); ?></p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi"><?php echo e($tlbi->tipe_transaksi == 4 ? $tlbi->jumlah : '-'); ?></p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi">-</p>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sikas/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/faisal/Documents/IlliyinStudio/Web/sikas/resources/views/sikas/laporan.blade.php ENDPATH**/ ?>