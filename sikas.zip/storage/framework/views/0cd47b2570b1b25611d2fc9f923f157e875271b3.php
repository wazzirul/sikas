<!-- BEGIN: Theme CSS-->
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/fonts/boxicons.css'))); ?>" />

<!-- Core CSS -->
<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/css/core.css'))); ?>" />
<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/css/theme-default.css'))); ?>" />
<link rel="stylesheet" href="<?php echo e(asset(mix('assets/css/demo.css'))); ?>" />

<link rel="stylesheet" href="<?php echo e(asset(mix('assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css'))); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome-free-6.2.1/css/all.min.css')); ?>" />

<!-- Vendor Styles -->
<?php echo $__env->yieldContent('vendor-style'); ?>


<!-- Page Styles -->
<?php echo $__env->yieldContent('page-style'); ?>
<?php /**PATH /Users/faisal/Documents/IlliyinStudio/Web/sikas/resources/views/layouts/sections/styles.blade.php ENDPATH**/ ?>