<?php $__env->startSection('title', 'Reset Tahun Ajar - Sikas'); ?>

<?php $__env->startSection('vendor-style'); ?>
<!-- <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.css')); ?>"> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<!-- <script src="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/pages/reset-tahun-ajar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/sikas-reset-tahun-ajar.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('current-pages-title'); ?>
  Reset Tahun Ajar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card--reset-tahun-ajar">
  <div class="card-body">
    <div class="text-center reset-tahun-ajar__content">
      <h4 class="text-bold text-danger reset-tahun-ajar__title">RESET TAHUN AJAR</h4>
      <p class="color-black reset-tahun-ajar__subtitle">Memulai tahun ajaran baru, <span class="text-primary text-bold">semua siswa dan siswi akan secara otomatis naik kelas</span>. Jika ada siswa / siswi yang tidak naik kelas, harap di ubah secara manual di menu siswa.</p>
    </div>
    <div class="d-flex flex-row align-items-stretch gap-3 mt-5">
      <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#modalEditData">Mulai Tahun Ajar Baru</button>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal modal--reset-tahun-ajar fade" id="modalEditData" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="d-flex justify-content-between align-items-center gap-3">
          <h4 class="color-black text-bold mb-4">Mulai Tahun Ajar Baru</h4>
          <a href="#" data-bs-dismiss="modal" class="text-danger" aria-label="Close">
            <i class="fa-solid fa-xmark icon"></i>
          </a>
        </div>
        <form action="/query/resetTahunAjar" method="POST" id="myform">
          <?php echo e(csrf_field()); ?>

          <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h5 class="text-bold text-primary mb-2">Kelas <?php echo e($t->Kelas->nama); ?></h5>
          <div class="mb-3">
            <label for="jenis_pembayaran<?php echo e($t->id_tagihan); ?>" class="form-label">Nama / Jenis Pembayaran</label>
            <input type="text" class="form-control" id="jenis_pembayaran<?php echo e($t->id_tagihan); ?>" name="jenis_pembayaran<?php echo e($t->id_tagihan); ?>" placeholder="Nama / Jenis Pembayaran..." value="<?php echo e($t->nama); ?>">
          </div>
          <div class="">
            <label for="nominal<?php echo e($t->id_tagihan); ?>" class="form-label">Nominal Pembayaran</label>
            <input type="text" class="form-control nominal-pembayaran" id="nominal<?php echo e($t->id_tagihan); ?>" name="nominal<?php echo e($t->id_tagihan); ?>" placeholder="Nominal Pembayaran..." value="<?php echo e($t->jumlah); ?>">
          </div>
          <div class="modal-line"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <div class="form-text"> <span class="text-primary text-bold">semua siswa dan siswi akan secara otomatis naik kelas</span>. Jika ada siswa / siswi yang tidak naik kelas, harap di ubah secara manual di menu siswa. </div>
          <div class="d-flex flex-row align-items-stretch gap-3 mt-5">
            <button type="submit" class="btn btn-primary w-100">Mulai Tahun Ajar Baru</button>
            <button type="button" class="success-button d-none" data-bs-toggle="modal" data-bs-target="#modalEditSuccess"></button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal modal--reset-tahun-ajar fade" id="modalEditSuccess" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <div class="d-flex flex-column justify-content-center align-items-center text-center">
          <i class="fa-solid fa-circle-check icon-success text-success"></i>
          <h4 class="color-neutral-100 mt-3 my-2">Selamat! Berhasil Memulai Tahun Ajar Baru</h4>
          <p class="color-neutral-80">Tahun Ajar Baru Berhasil dimulai, <span class="text-primary text-bold">semua siswa dan siswi akan secara otomatis naik kelas</span>. Jika ada siswa / siswi yang tidak naik kelas, harap di ubah secara manual di menu siswa. </p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sikas/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/faisal/Documents/IlliyinStudio/Web/sikas/resources/views/sikas/reset-tahun-ajar.blade.php ENDPATH**/ ?>