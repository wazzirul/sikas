<?php $__env->startSection('title', 'Transaksi Pembayaran - Sikas'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/daterangepicker/daterangepicker.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/pages/pembayaran-tabungan.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/sikas-pembayaran.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('current-pages-title'); ?>
  Transaksi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p class="fw-bold mb-5">
  <span class="text-muted fw-light">Transaksi /</span> Tabungan
</p>
<div class="jenis-pembayaran">
  <div class="card">
    <div class="card-body">
      <a href="<?php echo e(route('sikas-transaksi--tabungan-siswa')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-pembayaran__link">
        <div class="jenis-pembayaran__icon-wrap">
          <i class="fa-regular fa-credit-card jenis-pembayaran__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-pembayaran__icon jenis-pembayaran__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5">Pembayaran Tabungan Siswa</h5>
    </div>
  </div>
  <div class="card">
    <div class="card-body">
      <a href="<?php echo e(route('sikas-transaksi--tabungan-guru')); ?>" class="d-flex justify-content-between align-items-center gap-3 jenis-pembayaran__link">
        <div class="jenis-pembayaran__icon-wrap">
          <i class="fa-solid fa-credit-card jenis-pembayaran__icon"></i>
        </div>
        <i class="fa-solid fa-chevron-right jenis-pembayaran__icon jenis-pembayaran__icon--link"></i>
      </a>
      <h5 class="text-bold color-black mt-5">Pembayaran Tabungan Guru</h5>
    </div>
  </div>
</div> 
<div class="card riwayat-transaksi mt-5">
  <h4 class="color-neutral-100 mb-5">Riwayat Transaksi</h4>
  <div class="nav-align-top mb-4">
      <ul class="nav nav-pills mb-3" role="tablist">
        <li class="nav-item">
          <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab" data-bs-target="#navs-pills-tabungan-siswa" aria-controls="navs-pills-tabungan-siswa" aria-selected="true">Tabungan Siswa</button>
        </li>
        <li class="nav-item">
          <button type="button" class="nav-link" role="tab" data-bs-toggle="tab" data-bs-target="#navs-pills-tabungan-guru" aria-controls="navs-pills-tabungan-guru" aria-selected="false">Tabungan Guru</button>
        </li>
      </ul>
      <div class="tab-content">
        <div class="tab-pane fade show active" id="navs-pills-tabungan-siswa" role="tabpanel">
          <?php if(count($tabungan_siswa) !== 0): ?>
          <div class="table-responsive text-nowrap tabel-siswa">
            <table class="table table-striped" id="riwayat-tabungan-siswa">
              <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>NIS</th>
                  <th>Nama</th>
                  <th>Nominal</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="tbody-tabungan-siswa">
                <?php $__currentLoopData = $tabungan_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <p><?php echo e(\Carbon\Carbon::parse($ts->tanggal)->format('F, d Y')); ?></p>
                  </td>
                  <td class="text-medium color-neutral-100"><?php echo e($ts->Anggota->nis); ?></td>
                  <td>
                    <p class="text-medium text-black"><?php echo e($ts->Anggota->nama); ?> 'Kelas <?php echo e($ts->Anggota->Kelas->nama); ?> <?php echo e($ts->Anggota->Jurusan->nama); ?> <?php echo e($ts->Anggota->nomor_kelas); ?>'</p>
                  </td>
                  <td>
                    <p class="text-bold text-black jumlah-pembayaran"><?php echo e($ts->jumlah); ?></p>
                  </td>
                  <td>
                    <div class="d-flex align-items-center justify-content-start gap-3">
                      <a href="/transaksi/history-transaksi-siswa/detail/<?php echo e($ts->Anggota->id_anggota); ?>" class="table__link-detail d-flex align-items-center gap-2">
                        Lihat Detail
                        <i class="fa-solid fa-eye"></i>
                      </a>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <?php else: ?>
          <div class="d-flex flex-column align-items-center justify-content-center text-center empty-state-siswa d-none">
            <img src="<?php echo e(asset('assets/img/sikas/empty-illustration.png')); ?>" alt="">
            <h4 class="text-bold color-neutral-100">Data Tabungan Siswa Kosong</h4>
            <p class="color-neutral-80">Silahkan tambahkan data tabungan terlebih dulu untuk melihat data tabungan siswa.</p>
          </div>
          <?php endif; ?>
        </div>

        <div class="tab-pane fade" id="navs-pills-tabungan-guru" role="tabpanel">
          <?php if(count($tabungan_guru) != 0): ?>
          <div class="table-responsive text-nowrap tabel-guru">
            <table class="table table-striped" id="riwayat-tabungan-guru">
              <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>NIP</th>
                  <th>Nama</th>
                  <th>Nominal</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="tbody-tabungan-guru">
              <?php $__currentLoopData = $tabungan_guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <p><?php echo e(\Carbon\Carbon::parse($tg->tanggal)->format('F, d Y')); ?></p>
                  </td>
                  <td class="text-medium color-neutral-100"><?php echo e($tg->Anggota->nip); ?></td>
                  <td>
                    <p class="text-medium text-black"><?php echo e($tg->Anggota->nama); ?> 'Jabatan <?php echo e($tg->Anggota->Jabatan != null ? $tg->Anggota->Jabatan->nama : "Guru"); ?>'</p>
                  </td>
                  <td>
                    <p class="text-bold text-black jumlah-pembayaran"><?php echo e($tg->jumlah); ?></p>
                  </td>
                  <td>
                    <div class="d-flex align-items-center justify-content-start gap-3">
                      <a href="/transaksi/history-transaksi-siswa/detail/<?php echo e($tg->Anggota->id_anggota); ?>" class="table__link-detail d-flex align-items-center gap-2">
                        Lihat Detail
                        <i class="fa-solid fa-eye"></i>
                      </a>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <?php else: ?>
          <div class="d-flex flex-column align-items-center justify-content-center text-center empty-state-guru">
            <img src="<?php echo e(asset('assets/img/sikas/empty-illustration.png')); ?>" alt="">
            <h4 class="text-bold color-neutral-100">Data Tabungan Guru Kosong</h4>
            <p class="color-neutral-80">Silahkan tambahkan data tabungan terlebih dulu untuk melihat data tabungan guru.</p>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sikas/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/faisal/Documents/IlliyinStudio/Web/sikas/resources/views/sikas/transaksi-pembayaran-tabungan.blade.php ENDPATH**/ ?>