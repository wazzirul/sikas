<?php $__env->startSection('title', 'Laporan Penggunaan Dana - Sikas'); ?>

<?php $__env->startSection('vendor-style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/libs/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<script src="<?php echo e(asset('assets/vendor/libs/daterangepicker/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/libs/daterangepicker/daterangepicker.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/js/datatable-tables.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/laporan.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/laporan-penggunaan-dana.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<!-- Page -->
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/css/pages/sikas-laporan.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('current-pages-title'); ?>
  Laporan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card card--laporan">
  <div class="laporan-wrapper">
    <h4 class="text-bold color-black mb-4">Data Laporan Penggunaan Dana</h4>    
    <div class="d-flex align-items-center justify-content-end gap-4 mb-5">
      <input type="hidden" id="ctoken" value="<?php echo e(csrf_token()); ?>">
      <div class="date-range">
        <div id="date-range-span" class="form-control">
          <span></span>
        </div>
        <i class="fa-regular fa-calendar-days date-range-icon text-primary"></i>
        <input type="hidden" name="date-range-input" value="" class="" id="date-range-input"/>
      </div>
      <button class="d-flex btn btn-primary gap-2 align-items-center" data-bs-toggle="modal" data-bs-target="#modalAddData">
        Cetak Laporan
        <i class="fa-solid fa-plus"></i>
      </button>
    </div>
    <div class="table-responsive text-nowrap">
      <table class="table table-striped" id="data-laporan-penggunaan-dana">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Jenis Transaksi</th>
            <th>Keterangan</th>
            <th>Jumlah Nominal</th>
          </tr>
        </thead>
        <tbody id="tbody-penggunaan-dana">
          <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <p class="text-medium color-neutral-100"><?php echo e(\Carbon\Carbon::parse($l->tanggal)->format('d F Y')); ?></p>
            </td>
            <td class="text-medium">
              <p class="text-medium color-neutral-100">Penggunaan Dana</p>              
            </td>
            <td>
              <p class="text-medium color-neutral-100"><?php echo e($l->nama_transaksi); ?></p>
            </td>
            <td>
              <p class="text-medium color-neutral-100 nominal-transaksi"><?php echo e($l->jumlah); ?></p>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sikas/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/faisal/Documents/IlliyinStudio/Web/sikas/resources/views/sikas/laporan-penggunaan-dana.blade.php ENDPATH**/ ?>