<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('struktur_sekolah', function (Blueprint $table) {
            $table->increments('id_struktur_sekolah');
            $table->unsignedInteger('id_anggota')->nullable();
            $table->foreign('id_anggota')->references('id_anggota')->on('anggota');
            $table->string('jabatan');

            $table->smallInteger('soft_delete')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('struktur_sekolah');
    }
};
